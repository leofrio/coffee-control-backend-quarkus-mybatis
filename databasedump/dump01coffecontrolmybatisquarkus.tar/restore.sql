--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Debian 15.1-1.pgdg110+1)
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: leonardogaspar
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO leonardogaspar;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: leonardogaspar
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: contribution_product; Type: TABLE; Schema: public; Owner: leonardogaspar
--

CREATE TABLE public.contribution_product (
    contribution_id integer NOT NULL,
    product_id integer NOT NULL,
    amount_given integer NOT NULL
);


ALTER TABLE public.contribution_product OWNER TO leonardogaspar;

--
-- Name: contributions; Type: TABLE; Schema: public; Owner: leonardogaspar
--

CREATE TABLE public.contributions (
    id integer NOT NULL,
    contribution_date date DEFAULT CURRENT_DATE NOT NULL,
    user_id integer NOT NULL,
    solicitation_id integer NOT NULL
);


ALTER TABLE public.contributions OWNER TO leonardogaspar;

--
-- Name: contributions_id_seq; Type: SEQUENCE; Schema: public; Owner: leonardogaspar
--

ALTER TABLE public.contributions ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.contributions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: product_storage; Type: TABLE; Schema: public; Owner: leonardogaspar
--

CREATE TABLE public.product_storage (
    id integer NOT NULL,
    product_id integer NOT NULL,
    current_amount integer NOT NULL,
    min_amount integer NOT NULL
);


ALTER TABLE public.product_storage OWNER TO leonardogaspar;

--
-- Name: product_storage_id_seq; Type: SEQUENCE; Schema: public; Owner: leonardogaspar
--

ALTER TABLE public.product_storage ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.product_storage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: products; Type: TABLE; Schema: public; Owner: leonardogaspar
--

CREATE TABLE public.products (
    id integer NOT NULL,
    product_name character varying(150) NOT NULL,
    description character varying(300) NOT NULL,
    min_user_amount integer NOT NULL,
    enabled boolean NOT NULL
);


ALTER TABLE public.products OWNER TO leonardogaspar;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: leonardogaspar
--

ALTER TABLE public.products ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: leonardogaspar
--

CREATE TABLE public.profiles (
    id integer NOT NULL,
    profile_type character varying(150) NOT NULL,
    description character varying(300) NOT NULL
);


ALTER TABLE public.profiles OWNER TO leonardogaspar;

--
-- Name: profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: leonardogaspar
--

ALTER TABLE public.profiles ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.profiles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: solicitation_product; Type: TABLE; Schema: public; Owner: leonardogaspar
--

CREATE TABLE public.solicitation_product (
    solicitation_id integer NOT NULL,
    product_id integer NOT NULL,
    asked_amount integer NOT NULL
);


ALTER TABLE public.solicitation_product OWNER TO leonardogaspar;

--
-- Name: solicitations; Type: TABLE; Schema: public; Owner: leonardogaspar
--

CREATE TABLE public.solicitations (
    id integer NOT NULL,
    solicitation_name character varying(150) NOT NULL,
    solicitation_date date DEFAULT CURRENT_DATE NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    assigned_user_id integer NOT NULL,
    solicitation_expiration date
);


ALTER TABLE public.solicitations OWNER TO leonardogaspar;

--
-- Name: solicitations_id_seq; Type: SEQUENCE; Schema: public; Owner: leonardogaspar
--

ALTER TABLE public.solicitations ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.solicitations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: leonardogaspar
--

CREATE TABLE public.users (
    id integer NOT NULL,
    full_name character varying(150) NOT NULL,
    registration character varying(40) NOT NULL,
    pword character varying(80) NOT NULL,
    profile_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.users OWNER TO leonardogaspar;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: leonardogaspar
--

ALTER TABLE public.users ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: contribution_product; Type: TABLE DATA; Schema: public; Owner: leonardogaspar
--

COPY public.contribution_product (contribution_id, product_id, amount_given) FROM stdin;
\.
COPY public.contribution_product (contribution_id, product_id, amount_given) FROM '$$PATH$$/3382.dat';

--
-- Data for Name: contributions; Type: TABLE DATA; Schema: public; Owner: leonardogaspar
--

COPY public.contributions (id, contribution_date, user_id, solicitation_id) FROM stdin;
\.
COPY public.contributions (id, contribution_date, user_id, solicitation_id) FROM '$$PATH$$/3383.dat';

--
-- Data for Name: product_storage; Type: TABLE DATA; Schema: public; Owner: leonardogaspar
--

COPY public.product_storage (id, product_id, current_amount, min_amount) FROM stdin;
\.
COPY public.product_storage (id, product_id, current_amount, min_amount) FROM '$$PATH$$/3385.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: leonardogaspar
--

COPY public.products (id, product_name, description, min_user_amount, enabled) FROM stdin;
\.
COPY public.products (id, product_name, description, min_user_amount, enabled) FROM '$$PATH$$/3387.dat';

--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: leonardogaspar
--

COPY public.profiles (id, profile_type, description) FROM stdin;
\.
COPY public.profiles (id, profile_type, description) FROM '$$PATH$$/3389.dat';

--
-- Data for Name: solicitation_product; Type: TABLE DATA; Schema: public; Owner: leonardogaspar
--

COPY public.solicitation_product (solicitation_id, product_id, asked_amount) FROM stdin;
\.
COPY public.solicitation_product (solicitation_id, product_id, asked_amount) FROM '$$PATH$$/3391.dat';

--
-- Data for Name: solicitations; Type: TABLE DATA; Schema: public; Owner: leonardogaspar
--

COPY public.solicitations (id, solicitation_name, solicitation_date, enabled, assigned_user_id, solicitation_expiration) FROM stdin;
\.
COPY public.solicitations (id, solicitation_name, solicitation_date, enabled, assigned_user_id, solicitation_expiration) FROM '$$PATH$$/3392.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: leonardogaspar
--

COPY public.users (id, full_name, registration, pword, profile_id) FROM stdin;
\.
COPY public.users (id, full_name, registration, pword, profile_id) FROM '$$PATH$$/3394.dat';

--
-- Name: contributions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leonardogaspar
--

SELECT pg_catalog.setval('public.contributions_id_seq', 630, true);


--
-- Name: product_storage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leonardogaspar
--

SELECT pg_catalog.setval('public.product_storage_id_seq', 134, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leonardogaspar
--

SELECT pg_catalog.setval('public.products_id_seq', 134, true);


--
-- Name: profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leonardogaspar
--

SELECT pg_catalog.setval('public.profiles_id_seq', 33, true);


--
-- Name: solicitations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leonardogaspar
--

SELECT pg_catalog.setval('public.solicitations_id_seq', 265, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leonardogaspar
--

SELECT pg_catalog.setval('public.users_id_seq', 133, true);


--
-- Name: contribution_product contribution_product_pkey; Type: CONSTRAINT; Schema: public; Owner: leonardogaspar
--

ALTER TABLE ONLY public.contribution_product
    ADD CONSTRAINT contribution_product_pkey PRIMARY KEY (contribution_id, product_id);


--
-- Name: contributions contributions_pkey; Type: CONSTRAINT; Schema: public; Owner: leonardogaspar
--

ALTER TABLE ONLY public.contributions
    ADD CONSTRAINT contributions_pkey PRIMARY KEY (id);


--
-- Name: product_storage product_storage_pkey; Type: CONSTRAINT; Schema: public; Owner: leonardogaspar
--

ALTER TABLE ONLY public.product_storage
    ADD CONSTRAINT product_storage_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: leonardogaspar
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: leonardogaspar
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: solicitation_product solicitation_product_pkey; Type: CONSTRAINT; Schema: public; Owner: leonardogaspar
--

ALTER TABLE ONLY public.solicitation_product
    ADD CONSTRAINT solicitation_product_pkey PRIMARY KEY (solicitation_id, product_id);


--
-- Name: solicitations solicitations_pkey; Type: CONSTRAINT; Schema: public; Owner: leonardogaspar
--

ALTER TABLE ONLY public.solicitations
    ADD CONSTRAINT solicitations_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: leonardogaspar
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_registration_key; Type: CONSTRAINT; Schema: public; Owner: leonardogaspar
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_registration_key UNIQUE (registration);


--
-- Name: solicitations fk_assigned_user; Type: FK CONSTRAINT; Schema: public; Owner: leonardogaspar
--

ALTER TABLE ONLY public.solicitations
    ADD CONSTRAINT fk_assigned_user FOREIGN KEY (assigned_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: contribution_product fk_contribution; Type: FK CONSTRAINT; Schema: public; Owner: leonardogaspar
--

ALTER TABLE ONLY public.contribution_product
    ADD CONSTRAINT fk_contribution FOREIGN KEY (contribution_id) REFERENCES public.contributions(id) ON DELETE CASCADE;


--
-- Name: contributions fk_contribution_user; Type: FK CONSTRAINT; Schema: public; Owner: leonardogaspar
--

ALTER TABLE ONLY public.contributions
    ADD CONSTRAINT fk_contribution_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: product_storage fk_product; Type: FK CONSTRAINT; Schema: public; Owner: leonardogaspar
--

ALTER TABLE ONLY public.product_storage
    ADD CONSTRAINT fk_product FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: contribution_product fk_product; Type: FK CONSTRAINT; Schema: public; Owner: leonardogaspar
--

ALTER TABLE ONLY public.contribution_product
    ADD CONSTRAINT fk_product FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: solicitation_product fk_product; Type: FK CONSTRAINT; Schema: public; Owner: leonardogaspar
--

ALTER TABLE ONLY public.solicitation_product
    ADD CONSTRAINT fk_product FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: users fk_profile; Type: FK CONSTRAINT; Schema: public; Owner: leonardogaspar
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_profile FOREIGN KEY (profile_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: contributions fk_solicitation; Type: FK CONSTRAINT; Schema: public; Owner: leonardogaspar
--

ALTER TABLE ONLY public.contributions
    ADD CONSTRAINT fk_solicitation FOREIGN KEY (solicitation_id) REFERENCES public.solicitations(id) ON DELETE CASCADE;


--
-- Name: solicitation_product fk_solicitation; Type: FK CONSTRAINT; Schema: public; Owner: leonardogaspar
--

ALTER TABLE ONLY public.solicitation_product
    ADD CONSTRAINT fk_solicitation FOREIGN KEY (solicitation_id) REFERENCES public.solicitations(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

